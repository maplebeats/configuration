将/table/qqwubi.db复制到/usr/share/ibus-table/tables
将/icons/qqwubi.png复制到/usr/share/ibus-table/icons
重启ibus
进入iBus设置
输入法
选择输入法中添加QQ五笔即可。
